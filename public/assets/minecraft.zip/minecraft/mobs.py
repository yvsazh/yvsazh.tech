from ursina import *
from numpy import floor
from perlin_noise import PerlinNoise
from random import *
ZombieModel = load_model('AnyConv.com__zombie (1).obj')
Zombie = 'zombie.png'
class Mobs():
    def __init__(self):
        self.noise = PerlinNoise(seed=randrange(1, 100000000000000000000000000000000000))
        self.mobs = []

    def checkMob(self, _x,_y,_z):
        freq = 5
        amp = 100
        mobChance = ((self.noise([_x/freq,_z/freq]))*amp)
        if mobChance > .1:
            self.spawnMob(_x,_y,_z)

    def spawnMob(self,_x,_y,_z):
        if len(self.mobs) < 100:
            zombie = Entity(model=ZombieModel, texture=Zombie, scale=0.07, double_sided=True, position = (_x, _y, _z))
            self.mobs.append(zombie)
        else:
            pass