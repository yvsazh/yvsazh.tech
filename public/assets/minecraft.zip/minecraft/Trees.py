from perlin_noise import PerlinNoise
from ursina import Entity, color, Vec3
from random import randrange
Log = 'dirt_block.png'
leaves = 'leaves.png'
# GrassModel = 'GrassCube.obj'
GrassModel = "assets/block.obj"
class Trees():
    def __init__(self):
        self.noise = PerlinNoise(seed=randrange(1, 100000000000000000000000000000000000))
        self.trees = []

    def checkTree(self, _x,_y,_z):
        freq = 5
        amp = 100
        treeChance = ((self.noise([_x/freq,_z/freq]))*amp)
        if treeChance > .1:
            self.plantTree(_x,_y,_z)

    def plantTree(self,_x,_y,_z):
        if len(self.trees) < 300:
            tree = Entity(  model = None,
                            position=Vec3(_x,_y,_z))
            global trunk
            trunk = Entity( model=GrassModel,texture=Log,scale_y = randrange(5, 7),collider='mesh', scale_x=0.5, scale_z=0.5)
            crown = Entity( model='cube',scale=8,y=trunk.y+trunk.scale_y,texture=leaves)
            crown.parent=tree
            trunk.parent=tree
            tree.y = 3
            self.trees.append(tree)
        else:
            pass