class BTYPE:
	Grass = 'grassCube.png'
	GrassModel = 'GrassCube.obj'
	Brick = 'brick.png'
	Sand = 'sand.png'
	Log = 'log.png'
	Air = 'air.png'