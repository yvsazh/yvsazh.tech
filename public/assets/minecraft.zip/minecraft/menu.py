from ursina import *

class Menu(Entity):
	def __init__(self):
		super().__init__()

		self.parent = camera.ui
		self.model = "cube"
		self.roundness = 5
		self.color = color.rgba(59, 55, 55, a=200)  
		self.position = (0,0,0)
		self.scale = (1.2, .8, 0)

		self.block_pick = "grass"

		#buttons

		self.grass = Button(parent = self, color=color.white, texture = "grass.jpg", scale=(.09, .14, 0), position = (-.4, .3, 0))
		self.grass.on_click = self.changeBlockGrass
		self.grass.tooltip = Tooltip('grass')

		self.stone = Button(parent = self, color=color.white, texture = "stone.jpg", scale=(.09, .14, 0), position = (-.3, .3, 0))
		self.stone.on_click = self.changeBlockStone
		self.stone.tooltip = Tooltip('stone')

		self.brick = Button(parent = self, color=color.white, texture = "brick.jpg", scale=(.09, .14, 0), position = (-.2, .3, 0))
		self.brick.on_click = self.changeBlockBrick
		self.brick.tooltip = Tooltip('brick')

		self.dirt = Button(parent = self, color=color.white, texture = "dirt.jpg", scale=(.09, .14, 0), position = (-.1, .3, 0))
		self.dirt.on_click = self.changeBlockDirt
		self.dirt.tooltip = Tooltip('dirt')

		self.glass = Button(parent = self, color=color.white, texture = "glass.png", scale=(.09, .14, 0), position = (0, .3, 0))
		self.glass.on_click = self.changeBlockGlass
		self.glass.tooltip = Tooltip('glass')

	def changeBlockGrass(self):
		self.block_pick = "grass"
	def changeBlockStone(self):
		self.block_pick = "stone"
	def changeBlockBrick(self):
		self.block_pick = "brick"
	def changeBlockDirt(self):
		self.block_pick = "dirt"
	def changeBlockGlass(self):
		self.block_pick = "glass"

if __name__ == "__main__":
	app = Ursina()
	window.color = color.azure
	menu = Menu()
	app.run()