
from ursina import *
from player import Player
from numpy import floor
from perlin_noise import PerlinNoise
from random import *
from blocks import BTYPE
from Trees import Trees
from mobs import Mobs

app = Ursina()
life = Trees()
player = Player()
player.y = 20
window.color = color.cyan
Grass = 'assets/grass_block.png'
Stone = "assets/stone_block.png"
Brick = "assets/brick_block.png"
Dirt = "assets/dirt_block.png"
Glass = "assets/glass_block.png"
block_pick = "grass"
noise = PerlinNoise(octaves=2,seed=randrange(1, 100000000000000000000000000000000000))
amp = 6
freq = 24

class Voxel(Button):
	def __init__(self, position, texture = Grass):
		super().__init__(
			parent = scene,
			model = 'assets/block',
			position = position,
			origin_y = 0.5,
			texture = texture,
			color = color.color(0,0,uniform(0.9,1)),
			scale = 0.5)

	def input(self,key):
		if self.hovered:
			if key == 'right mouse down':
				if block_pick == "grass": voxel = Voxel(position = self.position + mouse.normal, texture = Grass)
				if block_pick == "stone": voxel = Voxel(position = self.position + mouse.normal, texture = Stone)
				if block_pick == "brick": voxel = Voxel(position = self.position + mouse.normal, texture = Brick)
				if block_pick == "dirt": voxel = Voxel(position = self.position + mouse.normal, texture = Dirt)
				if block_pick == "glass": voxel = Voxel(position = self.position + mouse.normal, texture = Glass)
			
			if key == 'left mouse down':
				destroy(self)

class Sky(Entity):
	def __init__(self):
		super().__init__()
		self.parent = scene
		self.model = "sphere"
		self.color = color.cyan
		self.scale = 12
		self.double_sided = True
		self.scale_y = 30

class Hand(Entity):
	def __init__(self):
		super().__init__(
			parent = camera.ui,
			model = 'assets/arm',
			texture = "assets/arm_texture.png",
			scale = 0.2,
			rotation = Vec3(150,-10,0),
			position = Vec2(0.4,-0.6))

hand = Hand()
sky = Sky()

# generate trees
def genTrees(_x, _z, plantTree=True):
	y = 1
	freq = 32
	amp = 21
	y += ((noise([_x/freq,_z/freq]))*amp)
	if plantTree==True:
		life.checkTree(_x,y,_z)

# make terretory
shells = []
shellWidth = 12
for i in range(shellWidth*shellWidth):
	ent = Voxel((0,0,0))
	shells.append(ent)
# generate Terretory
def genTerr():
	global amp, freq
	for i in range(len(shells)):
		x = shells[i].x = floor((i/shellWidth) + player.x - .5*shellWidth)
		z = shells[i].z = floor((i%shellWidth) + player.z - .5*shellWidth)
		y = shells[i].y = floor(noise([x/freq, z/freq])*amp)

# update function
def update():
	global block_pick
	if player.y < -3:
		player.y = 10
	block_pick = player.menu.block_pick
	sky.x = player.x
	sky.z = player.z
	sky.y = player.y
	genTrees(randrange(-100, 100), randrange(-100, 100))
	genTerr()


app.run()