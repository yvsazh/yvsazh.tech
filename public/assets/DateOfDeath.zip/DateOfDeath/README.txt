Для того щоб запустити програму потрібно встановити PYTHON з веб-сайту python.org. 
Після того як ви встановили PYTHON запустіть командну строку Windows.
Там введіть команду pip install PyQt5 та почекайте.
Далі відкрийте командну строку в папці з файлом main.py та введіть команду python main.py.
Насолоджуйтесь програмою!
_______________________________________________________

To run the program you have to install PYTHON from python.org.
After that you habe to open Windows command prompt.
Run the pip install PyQt5 command and wait a bit.
Than open command prompt in the folder with main.py file.
Enjoy the programm!

