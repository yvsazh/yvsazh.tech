from PyQt5 import QtCore, QtGui, QtWidgets
import random


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(683, 434)
        MainWindow.setMinimumSize(QtCore.QSize(683, 434))
        MainWindow.setMaximumSize(QtCore.QSize(683, 434))
        MainWindow.setStyleSheet("background: black;")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.ageline = QtWidgets.QLineEdit(self.centralwidget)
        self.ageline.setGeometry(QtCore.QRect(140, 90, 391, 41))
        self.ageline.setStyleSheet("border: 3px solid red;\n"
"font: 10pt \"Algerian\";\n"
"font-size: 20px;\n"
"color: white;\n"
"border-radius: 10px;\n"
"background: black;")
        self.ageline.setObjectName("ageline")
        self.yearline = QtWidgets.QLineEdit(self.centralwidget)
        self.yearline.setGeometry(QtCore.QRect(140, 160, 391, 41))
        self.yearline.setStyleSheet("border: 3px solid red;\n"
"font: 10pt \"Algerian\";\n"
"font-size: 20px;\n"
"color: white;\n"
"border-radius: 10px;\n"
"background: black;")
        self.yearline.setObjectName("yearline")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(80, 10, 521, 61))
        self.label.setMaximumSize(QtCore.QSize(99999, 9999))
        self.label.setStyleSheet("color: red;\n"
"font: 10pt \"Algerian\";\n"
"text-align: center;\n"
"font-size: 70px;")
        self.label.setObjectName("label")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(260, 220, 141, 41))
        self.pushButton.setStyleSheet("QPushButton {\n"
"color: red;\n"
"font-size: 15px;\n"
"border: 3px solid red;\n"
"border-radius: 20px;\n"
"background: black;\n"
"transition: 1s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"color: black;\n"
"background: red;\n"
"transition: 1s;\n"
"}")
        self.pushButton.setObjectName("pushButton")
        self.result = QtWidgets.QLabel(self.centralwidget)
        self.result.setGeometry(QtCore.QRect(120, 280, 431, 101))
        self.result.setStyleSheet("color: red;\n"
"font-size: 20px;")
        self.result.setObjectName("result")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 683, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)


        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.add_functions()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.ageline.setPlaceholderText(_translate("MainWindow", "Введите ваш возраст"))
        self.yearline.setPlaceholderText(_translate("MainWindow", "Введите свой год рождения"))
        self.label.setToolTip(_translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">DateOfDeath</span></p></body></html>"))
        self.label.setWhatsThis(_translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>"))
        self.label.setText(_translate("MainWindow", "Date Of Death"))
        self.pushButton.setText(_translate("MainWindow", "Узнать"))

    def add_functions(self):
        self.pushButton.clicked.connect(self.Death)

    def Death(self):
        self.age = ui.ageline.text()
        self.year = ui.yearline.text()
        try:
            self.age = int(self.age)
            self.year = int(self.year)
        except Exception:
            self.result.setText("Введите только числа!")
        if self.year == "" and self.age == "":
            self.result.setText("Вы ничего не вписали!")
        elif int(self.year) < 1:
            self.result.setText("Такой год не возможен!")
        elif int(self.age) <= 0:
            self.result.setText("Такой возраст не возможен!")
        elif int(self.age) >= 130:
            self.result.setText("Такой возраст не возможен!")

        else:
            self.agep = random.randint(1, 70)
            self.dage = int(self.age) + int(self.agep)
            self.dyear = int(self.year) + int(self.age) + int(self.agep)
            self.month = [
                "январе",
                "марте",
                "апреле",
                "октябре",
                "июне",
                "июле",
                "августе",
                "сентябре",
                "мае",
                "ноябре",
                "декабре"
            ]
            self.dcause = None
            self.dm = None
            self.death1 = [
                "того, что вас собьет машина",
                "того, что в вас попадет пуля",
                "того, что вы сгорите"
            ]
            self.death2 = [
                "инсульта",
                "инфаркта",
                "остановки сердца",
                "камней в почках",
                "того, что вы утоните",
                "того, что вас проткнут ножом",
                "сумасшедшей жены"
            ]
            self.death3 = [
                "того, что тебя убьет кочелей",
                "падения в слив в дощевую погоду",
                "рук серийного убийцы",
                "того, что вас убьет дубинкой",
                "дикого животного",
                "упавшего на вас камня",
                "того, что вы упадете с горы",
                "молнии"
            ]

            self.dm = random.choice(self.month)
            self.dd = random.randint(1, 30)

            if self.dage >= 70:
                self.dcause = "старости."
            elif self.dage <= 40:
                self.dcause = random.choice(self.death1)
            elif self.dage >= 40:
                self.dcause = random.choice(self.death2)
            elif self.dage <= 18:
                self.dcause = random.choice(self.death3)

            self.result.setText("Вы умрете в " + str(self.dm) + " " + str(self.dd) + "-ого числа" + " в " + str(
                self.dyear) + " году," + "\n" + " когда вам будет " + str(self.dage) + "\n" + " Вы умрете от " + str(self.dcause))






if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
